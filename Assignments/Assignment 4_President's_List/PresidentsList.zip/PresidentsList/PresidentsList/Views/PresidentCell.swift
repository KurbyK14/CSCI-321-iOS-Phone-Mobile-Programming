//
//  PresidentCell.swift
//  PresidentsList
//
//  Created by Terry Kucala z1943275 and Jacob Kurbis z1945650.
//  Due on: 4/11/23.
//

import SwiftUI

struct PresidentCell: View {
    
    var president: PresidentViewModel
    
    var body: some View {
        //Cell option
        HStack {
            VStack(alignment: .leading) {
                
                //name
                Text(president.name)
                    .font(.headline)
                    .fontWeight(.heavy)
                //political party
                Text(president.politicalParty)
                    .font(.subheadline)
            }
        }
    }
}

struct PresidentCell_Previews: PreviewProvider {
    static var previews: some View {
        PresidentCell(president: PresidentViewModel.default)
    }
}
