//
//  ContentView.swift
//  PresidentsList
//
//  Created by Terry Kucala z1943275 and Jacob Kurbis z1945650.
//  Due on: 4/11/23.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var presidentListVM = PresidentListViewModel()
    
    var body: some View {
        //Scrollable and clickable stack with presidents names
        NavigationStack {
            //Lists all presidents to be selected
            List {
                ForEach(presidentListVM.presidents, id: \.name) {
                    presidentVM in
                    //Once a president is selected
                    NavigationLink(destination: PresidentDetailView(president: presidentVM)) {
                        PresidentCell(president: presidentVM)
                    }
                }
            }
            .listStyle(.plain)
            .navigationTitle("Presidents")
            .navigationBarTitleDisplayMode(.inline)
            
        }
        //loads the presidents information
        .onAppear {
            presidentListVM.loadPropertyList()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
