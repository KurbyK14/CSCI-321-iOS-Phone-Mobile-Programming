//
//  PresidentDetailView.swift
//  PresidentsList
//
//  Created by Terry Kucala z1943275 and Jacob Kurbis z1945650.
//  Due on: 4/11/23.
//

import SwiftUI

struct PresidentDetailView: View {
    
    var president: PresidentViewModel
    
    var body: some View {
        VStack {
            //name
            Text(president.name)
                .font(.title)
                .fontWeight(.bold)
                .padding(.bottom, 0.0)
                .padding(.top, -50.0)
            
            //president number
            Text("\(president.number) President of the United States")
                .fontWeight(.medium)
                .padding(.bottom, 5.0)
            
            //Start date to end date
            HStack{
                Text("(\(president.startDate) to \(president.endDate))")
                    .italic()
            }

            //presidential seal image
            Image("seal")
                .resizable()
                .frame(width: 275, height: 425)
            
            //presidents nickname title
            Text("Nickname")
                .font(.headline)
                .padding(.bottom, 5.0)
            
            //presidents nickname(s)
            Text(president.nickname)
                .font(.body)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            
            //political party title
            Text("Political Party")
                .font(.headline)
                .bold()
                .padding(.top, 1.0)
            
            //presidents political party
            Text(president.politicalParty)
                .font(.body)
                .padding(.top, 1.0)
        }
    }
}

struct PresidentDetailView_Previews: PreviewProvider {
    static var previews: some View {
        PresidentDetailView(president: PresidentViewModel.default)
    }
}
