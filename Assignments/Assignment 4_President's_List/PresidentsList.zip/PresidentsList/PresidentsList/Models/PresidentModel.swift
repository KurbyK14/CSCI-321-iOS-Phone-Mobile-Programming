//
//  PresidentModel.swift
//  PresidentsList
//
//  Created by Terry Kucala z1943275 and Jacob Kurbis z1945650.
//  Due on: 4/11/23.
//

import Foundation

//create a president object with the spicified variables located in the plist
struct President: Decodable {
    var name = ""
    var number: Int
    var startDate = ""
    var endDate = ""
    var nickname = ""
    var politicalParty = ""
    
    //keys for the variables to match from the plist
    private enum CodingKeys: String, CodingKey {
        case name = "Name"
        case number = "Number"
        case startDate = "Start Date"
        case endDate = "End Date"
        case nickname = "Nickname"
        case politicalParty = "Political Party"
    }
}
