//
//  PresidentsListApp.swift
//  PresidentsList
//
//  Created by Terry Kucala z1943275 and Jacob Kurbis z1945650.
//  Due on: 4/11/23.
//

import SwiftUI

@main
struct PresidentsListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
