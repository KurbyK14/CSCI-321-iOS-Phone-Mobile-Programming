//
//  PresidentViewModel.swift
//  PresidentsList
//
//  Created by Terry Kucala z1943275 and Jacob Kurbis z1945650.
//  Due on: 4/11/23.
//

import Foundation

//used to add the ordinal to the end of the number variable
extension Int {
    var ordinal: String {
        let lastDigit = self % 10
        let suffix: String
        switch lastDigit {
        case 1:
            suffix = "st"
        case 2:
            suffix = "nd"
        case 3:
            suffix = "rd"
        default:
            suffix = "th"
        }
        return "\(self)\(suffix)"
    }
}

struct PresidentViewModel {
    //The president
    var president: President
    
    //returns the presidents name
    var name: String {
        return president.name
    }
    
    //returns the presidents number and adds the ordinal formater at the end
    var number: String {
        return president.number.ordinal
    }
    
    //returns the presidents start date
    var startDate: String {
        return president.startDate
    }
    
    //returns the presidents end date
    var endDate: String {
        return president.endDate
    }
    
    //returns the presidents nickname(s)
    var nickname: String {
        return president.nickname
    }
    
    //returns the political party of the president
    var politicalParty: String {
        return president.politicalParty
    }
    
    //used to test the view for the presidents in the other views
    static var `default`: PresidentViewModel {
        let president = President(name: "firstName lastName", number: 0, startDate: "January 1, 2020", endDate: "January 2, 2021", nickname: "nickname", politicalParty: "party")
       return PresidentViewModel(president: president)
    }
}
