//
//  PresidentListViewModel.swift
//  PresidentsList
//
//  Created by Terry Kucala z1943275 and Jacob Kurbis z1945650.
//  Due on: 4/11/23.
//

import Foundation

class PresidentListViewModel: ObservableObject {
    
    //create an array of presidents
    @Published var presidents: [PresidentViewModel] = []
    
    //loads the presidents information from the plist xml file
    func loadPropertyList() {
        guard let path = Bundle.main.path(forResource: "presidents", ofType: "plist"), let xml = FileManager.default.contents(atPath: path) else { fatalError("Unable to access the property list presidents.plist")}

            do {
                //decodes the information if there was no fatal error before
                var presidents = try PropertyListDecoder().decode([President].self, from: xml)
                
                //sorts them by order of number
                presidents.sort {
                    $0.number < $1.number
                }
                
                //initializes all presidents
                self.presidents = presidents.map(PresidentViewModel.init)
                
            //catches if the list was not decoded
            } catch {
                fatalError("Unable to decode the property list presidents.plist")
            }
        }
    }

