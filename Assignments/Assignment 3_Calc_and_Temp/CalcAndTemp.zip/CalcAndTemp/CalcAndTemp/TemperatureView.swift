//
//  Temperature.swift
//  CalcAndTemp
//
//  Created by Terry Kucala z1943275 and Jacob Kurbis z1945650.
//  Due on: 3/30/23.
//

import SwiftUI

struct TemperatureView: View {
    
    //F -> C, C -> F
    var selectedTemps = ["\u{2109}\u{2B62}\u{2103}", "\u{2103}\u{2B62}\u{2109}"]
    //defalt conversion is F->C
    @State private var selectedTemp = "\u{2109}\u{2B62}\u{2103}"
    //Start both wheels at 0
    @State var selectedFar = 0
    @State var selectedCel = 0
    //Check to see what conversion is selected from the segmented view
    @State var selected = 1
    
    // calculates the F -> C conversion
    var FtoCOutput: Double {
        let tempinput = Double(selectedFar)
        var output = 0.0
        
        output = (tempinput - 32) * 5 / 9
        
        return output
    }
    
    // calculates the C -> F conversion
    var CtoFOutput: Double {
        let tempinput = Double(selectedCel)
        var output = 0.0
        
        output = tempinput * 9 / 5 + 32
        
        return output
    }
    
    var body: some View {
        VStack {
            
            //Title on top of screen
            Text("Temperature Conversion")
                .font(.title)
                .fontWeight(.bold)
                .padding(.vertical, 15)
            
            // segmented picker that allows the user to select which conversion they want
            Picker(selection:$selected, label: Text("Picker"), content: {
                Text("\u{2109}\u{2B62}\u{2103}").tag(1)
                Text("\u{2103}\u{2B62}\u{2109}").tag(2)
            })
            .pickerStyle(.segmented)
            
            // F -> C is selected
            if selected == 1 {
                Picker("FarValue", selection: $selectedFar) {
                    ForEach(-129...134, id: \.self) { value in
                        Text("\(value) \u{2109}")
                            .tag(value)
                    }
                }
                .pickerStyle(.wheel)
                
                // Prints the conversion below the picker
                Text("\(FtoCOutput, specifier: "%.2f") \u{2103}")
            }
            
            // C -> F is selected
            else {
                Picker("CelValue", selection: $selectedCel) {
                    ForEach(-90...57, id: \.self) { value in
                        Text("\(value) \u{2103}")
                            .tag(value)
                    }
                }
                .pickerStyle(.wheel)
                
                // Prints the conversion below the picker
                Text("\(CtoFOutput, specifier: "%.2f") \u{2109}")
            }
            Spacer()
        }
    }
}

struct Temperature_Previews: PreviewProvider {
    static var previews: some View {
        TemperatureView()
    }
}
