//
//  CalcAndTempApp.swift
//  CalcAndTemp
//
//  Created by Terry Kucala z1943275 and Jacob Kurbis z1945650.
//  Due on: 3/30/23.
//

import SwiftUI

@main
struct CalcAndTempApp: App {
    var body: some Scene {
        WindowGroup {
            TabView {
                //temperature conversion tab
                TemperatureView()
                    .tabItem {
                        Label("Temperature", systemImage: "thermometer")
                    }
                //mortgage loan calculator tab
                MortgageView()
                    .tabItem {
                        Label("Mortgage", systemImage: "house")
                    }
            }
        }
    }
}
