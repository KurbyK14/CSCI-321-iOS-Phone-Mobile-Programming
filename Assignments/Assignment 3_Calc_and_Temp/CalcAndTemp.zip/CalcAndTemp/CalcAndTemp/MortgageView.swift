//
//  ContentView.swift
//  CalcAndTemp
//
//  Created by Terry Kucala z1943275 and Jacob Kurbis z1945650.
//  Due on: 3/30/23.
//

import SwiftUI

struct MortgageView: View {
    
    //Result of the calculation of monthly payment
    @State private var result: Double = 0
    @State private var principle = ""
    @State private var interestTotal: Double = 0.01
    @State private var yearTotal: Double = 10.0
    @State private var showErrorAlert = false
    
    // Function to calculate the monthly payment
    // P = principal
    // R = monthly interest
    // N = total number of monthly payments over the lifetime of the loan
    func calculateMonthlyPayment() {
        let P = Double(principle) ?? 0
        let R = interestTotal / 100 / 12.0
        let N = Double(yearTotal) * 12.0
        let numerator = P * R * pow((1.0 + R), N)
        let denominator = pow((1.0 + R), N) - 1.0
        
        // monthly payment = (P x R x (1.0 + R) ^N) / ((1.0 + R) ^N - 1.0)
        result = numerator / denominator
    }
    
    var body: some View {
        // Vertical stack for the loan calculator
        VStack {
            // Title for the app tab
            Text("Loan Calculator")
                .font(.title)
                .fontWeight(.bold)
                .padding(.vertical, 15)
            
            // Text field that allows the usert to enter the principle of the loan
            TextField("Enter principle", text: $principle)
                .keyboardType(.decimalPad)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)
                .onChange(of: principle) { value in
                                    if let number = Double(value), number < 0 {
                                        showErrorAlert = true
                                        principle = ""
                                    }
                                }
                        .alert(isPresented: $showErrorAlert) {
                            Alert(
                                title: Text("Invalid Input"),
                                message: Text("Please enter a positive number"),
                                dismissButton: .default(Text("OK"))
                            )
                        }
            // A stepper that allows the user to change the annual interest rate in increments of 0.01 between 0.01 and 20.00
            HStack {
                Stepper("Interest", value: $interestTotal, in: 0.01...20, step: 0.01)
                    .font(.title2)
                    .fontWeight(.semibold)
                    .padding()
                Spacer()
            }
            
            // Shows the annual interest rate for the loan. Gets the number from the stepper above.
            HStack {
                Text("Annual Rate")
                    .font(.title3)
                    .fontWeight(.semibold)
                    .padding(.horizontal)
                Spacer()
                
                Text("\(interestTotal, specifier: "%.2f") %")
                    .padding()
            }
            
            // Shows the amount of years for the loan. Gets the number from the slider below.
            HStack {
                Text("Number of Years")
                    .font(.title3)
                    .fontWeight(.semibold)
                    .padding(.horizontal)
                Spacer()
                Text("\(yearTotal, specifier: "%.0f") years")
                    .padding(.horizontal)
            }
            
            // Slider that lets the user change the number of years for the loan in increments of 5 from 10-30 years
            Slider(value: $yearTotal, in: 10...30, step: 5, minimumValueLabel:Text("10"), maximumValueLabel: Text("30"), label: {Text("Years")})
                .padding(.horizontal)
                .padding(.vertical, 15)
            
            // Button that calls a function to calculate the monthly payment
            Button(action: calculateMonthlyPayment) {
                Text("Calculate")
                    .fontWeight(.bold)
                    .foregroundColor(Color.white)
                    .padding(16)
                    .background(Color.black)
                    .clipShape(Capsule())
            }
            .padding(.bottom)
            
            // Calculated montly payment (is 0 if there has been no input)
            HStack {
                Text("Monthly Payment")
                    .font(.title3)
                    .fontWeight(.semibold)
                    .padding(.horizontal)
                Spacer()
                Text("$\(result, specifier: "%.2f")")
                    .padding(.horizontal)
            }
            Spacer()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        MortgageView()
    }
}

