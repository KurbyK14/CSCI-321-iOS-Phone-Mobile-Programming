//
//  BooksApp.swift
//  Books
//
//  Created by: Jacob Kurbis (Z1945650)
//              Terry Kucala (Z1943275)
//              Due: 2/23/23.

import SwiftUI

@main
struct BooksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
