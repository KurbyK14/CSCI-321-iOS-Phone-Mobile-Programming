//
//  ContentView.swift
//  Books
//
//  Created by: Jacob Kurbis (Z1945650)
//              Terry Kucala (Z1943275)
//              Due: 2/23/23.

import SwiftUI

struct ContentView: View {
    let book = bookData
    var body: some View {
        ScrollView (.vertical, showsIndicators: false){
            VStack {
                
                //Image
                Image(book.image)
                    .resizable()
                    //.aspectRatio(contentMode: .fit)
                    .frame(width: 200, height: 250)
                    .cornerRadius(20)
                    .shadow(radius: 10)
                
                //Title
                Text(book.title)
                    .font(.title)
                    .multilineTextAlignment(.center)
                    .padding(.top)
                
                //Author
                Text(book.authors)
                    .foregroundColor(.secondary)
                    .font(.subheadline)
                
                //Description
                Text(book.description)
                    .font(.body)
                    .padding(.top)
                    .multilineTextAlignment(.leading)
                
                //Horizontal Categories
                HStack {
                    ForEach(book.categories, id: \.self) { category in
                        Text(category)
                            .foregroundColor(.black)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 5)
                            .background(Color.white)
                            .overlay(RoundedRectangle(cornerRadius: 16) .stroke(.black, lineWidth: 4))
                            .cornerRadius(15)
                            .padding(.vertical, 10)
                    }
                }
                
                Divider()
                .padding()
                
                //Buy Now Button
                Text("Buy for \(NumberFormatter.localizedString(from: NSNumber(value: book.price), number: .currency))")
                    .font(.headline)
                    .padding(.horizontal, 40)
                    .padding(.vertical, 12)
                    .foregroundColor(.white)
                    .background(Color.black)
                    .cornerRadius(25)
                    .padding(.bottom)

            }
            .padding()
            
        }

    }
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
}
