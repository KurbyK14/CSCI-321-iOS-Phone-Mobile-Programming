//
//  BookModel.swift
//  Books
//
//  Created by: Jacob Kurbis (Z1945650)
//              Terry Kucala (Z1943275)
//              Due: 2/23/23.

import Foundation

//Book Struct
struct Book: Identifiable {
    let id = UUID()
    let image: String
    let authors: String
    let title: String
    let edition: String
    let description: String
    let categories: [String]
    let price: Double
}
