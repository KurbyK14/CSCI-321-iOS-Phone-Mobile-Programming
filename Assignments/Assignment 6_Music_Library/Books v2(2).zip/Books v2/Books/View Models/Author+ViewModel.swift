//
//  Author+ViewModel.swift
//  Books
//
//  Created by Kurt McMahon on 4/20/23.
//

import Foundation

extension Author {
    
    var showName: String {
        return name ?? "Undefined"
    }
}
