//
//  Book+ViewModel.swift
//  Books
//
//  Created by Kurt McMahon on 4/18/23.
//

import Foundation
import UIKit

extension Book {
    
    var showTitle: String {
        return title ?? "Undefined"
    }
    
    var showYear: String {
        return String(year)
    }
    
    var showAuthor: String {
        return author ?? "Undefined"
    }
    
    var showCover: UIImage {
        if let data = cover, let image = UIImage(data: data) {
            return image
        } else {
            return UIImage(named: "nopicture")!
        }
    }

}
